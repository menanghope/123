Authors
-------

* Eric (New contributor)
* Anthony 

- https://karinov.co.id - jasa digital marketing indonesia
- https://www.tnol.co.id - forum modifikasi otomotif indonesia
- https://blogs.itb.ac.id/wikia - catatan hidup mahasiswa wikia alfa
- https://blogs.itb.ac.id/feeds - kumpulan tautan berita terbaru indonesia
- https://www.m-edukasi.web.id - portal bisnis online dan umkm
- https://www.pelita.or.id - harian pelita portal informasi terkini
